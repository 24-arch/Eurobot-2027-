#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>

// Set this to 1 for the first Arduino, and 2 for the second Arduino
#define RFNODE_ID 1

RF24 radio(9, 10); // CE, CSN pins

// Two distinct 5-byte addresses for the communication pipes
const byte addresses[][6] = {"Node1", "Node2"};

void setup() {
  Serial.begin(9600);
  radio.begin();
  radio.setPALevel(RF24_PA_LOW);

  if (RFNODE_ID == 1) {
    radio.openWritingPipe(addresses[0]);   // Node 1 sends to "Node1"
    radio.openReadingPipe(1, addresses[1]);// Node 1 receives on "Node2"
  } else {
    radio.openWritingPipe(addresses[1]);   // Node 2 sends to "Node2"
    radio.openReadingPipe(1, addresses[0]);// Node 2 receives on "Node1"
  }

  radio.startListening(); // Default state: listen for incoming data
  Serial.println("RF Transceiver Ready. Type a message and hit Enter:");
}

void loop() {
  // 1. CHECK FOR OUTGOING SERIAL MESSAGES
  if (Serial.available() > 0) {
    String inputStr = Serial.readStringUntil('\n');
    inputStr.trim(); // Remove trailing newline/carriage return characters

    if (inputStr.length() > 0) {
      char payload[32] = ""; // nRF24L01 payload limit is 32 bytes
      inputStr.toCharArray(payload, sizeof(payload));

      radio.stopListening(); // Pause listening to transmit
      bool sent = radio.write(&payload, sizeof(payload));
      radio.startListening(); // Resume listening

      if (sent) {
        Serial.print("[You]: ");
        Serial.println(payload);
      } else {
        Serial.println("[Error]: Message delivery failed.");
      }
    }
  }

  // 2. CHECK FOR INCOMING RADIO MESSAGES
  if (radio.available()) {
    char received[32] = "";
    radio.read(&received, sizeof(received));
    
    Serial.print("[Remote]: ");
    Serial.println(received);
  }
}